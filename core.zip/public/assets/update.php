<?php

// namespace app\public;

// class update{
//     public function update(){
//         echo json_encode(['msg'=>"something"]);
//     }
// }

echo json_encode("something");